# AskMind AI — AI-connected MVP

This version has a Flutter client + Node backend.

## 1) Backend
cd backend
npm install

Set the environment variable:
OPENAI_API_KEY=your_api_key_here

Then:
npm start

## 2) Flutter
From the project root:
flutter pub get
flutter run

Android emulator uses `http://10.0.2.2:3000/ask` for the local backend.
For a physical phone, replace that address with your computer's LAN IP and ensure the backend is reachable.

## Important
Do NOT put an OpenAI API key directly in the Flutter app. API keys must stay on a server/environment variable.
