import express from "express";
import cors from "cors";
import OpenAI from "openai";

const app = express();
app.use(cors());
app.use(express.json());

const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

app.post("/ask", async (req, res) => {
  try {
    const question = String(req.body?.question || "").trim();
    if (!question) return res.status(400).json({error: "Question required"});

    const prompt = `You are AskMind AI, a balanced decision-support assistant.
Answer in the user's language. Analyze the question from both constructive and critical perspectives.
Use exactly these sections:
1. Direct Answer
2. Positive Side
3. Negative Side
4. Risks & Safety
5. Alternatives
6. Final Recommendation
Never provide instructions that facilitate serious wrongdoing or harm; instead provide a safe alternative.
Question: ${question}`;

    const response = await client.responses.create({
      model: "gpt-5.6-luna",
      input: prompt
    });

    res.json({answer: response.output_text});
  } catch (err) {
    console.error(err);
    res.status(500).json({error: "AI request failed"});
  }
});

app.listen(3000, () => console.log("AskMind backend listening on :3000"));
