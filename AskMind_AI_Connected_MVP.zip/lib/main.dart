import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;

void main() => runApp(const AskMindApp());

class AskMindApp extends StatelessWidget {
  const AskMindApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'AskMind AI',
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF0B1020),
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple, brightness: Brightness.dark),
        useMaterial3: true,
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final controller = TextEditingController();
  final List<Map<String, String>> messages = [];

  Future<void> ask() async {
    final q = controller.text.trim();
    if (q.isEmpty) return;
    setState(() {
      messages.add({'role': 'user', 'text': q});
      messages.add({
        'role': 'ai',
        'text': 'مثالی جواب: میں اس سوال کو متوازن انداز میں دیکھوں گا۔\\n\\n'
            '✅ Positive: ممکنہ فائدے اور مواقع۔\\n'
            '⚠️ Negative: ممکنہ نقصانات اور کمزوریاں۔\\n'
            '🛡️ Risks: اہم خطرات اور احتیاط۔\\n'
            '💡 Alternatives: محفوظ یا بہتر متبادل۔\\n'
            '🎯 Recommendation: فیصلہ کرنے سے پہلے دونوں پہلوؤں کا موازنہ کریں۔\\n\\n'
            'نوٹ: یہ Demo Mode ہے۔ اصل AI جواب کے لیے secure backend/API connect کریں۔'
      });
      controller.clear();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('AskMind AI', style: TextStyle(fontWeight: FontWeight.bold)),
        actions: [
          IconButton(
            tooltip: 'Language',
            onPressed: () {},
            icon: const Icon(Icons.language),
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: messages.isEmpty
                ? const _Welcome()
                : ListView.builder(
                    padding: const EdgeInsets.all(16),
                    itemCount: messages.length,
                    itemBuilder: (_, i) {
                      final m = messages[i];
                      final user = m['role'] == 'user';
                      return Align(
                        alignment: user ? Alignment.centerRight : Alignment.centerLeft,
                        child: Container(
                          constraints: const BoxConstraints(maxWidth: 360),
                          margin: const EdgeInsets.only(bottom: 12),
                          padding: const EdgeInsets.all(14),
                          decoration: BoxDecoration(
                            color: user ? Colors.deepPurple.shade700 : const Color(0xFF171E33),
                            borderRadius: BorderRadius.circular(18),
                          ),
                          child: Text(m['text']!, style: const TextStyle(fontSize: 15, height: 1.4)),
                        ),
                      );
                    },
                  ),
          ),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(12, 6, 12, 12),
              child: Row(
                children: [
                  IconButton(onPressed: () {}, icon: const Icon(Icons.mic_none)),
                  IconButton(onPressed: () {}, icon: const Icon(Icons.attach_file)),
                  Expanded(
                    child: TextField(
                      controller: controller,
                      minLines: 1,
                      maxLines: 4,
                      onSubmitted: (_) => ask(),
                      decoration: InputDecoration(
                        hintText: 'اپنا سوال لکھیں...',
                        filled: true,
                        fillColor: const Color(0xFF171E33),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(22),
                          borderSide: BorderSide.none,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 6),
                  FloatingActionButton.small(onPressed: ask, child: const Icon(Icons.arrow_upward)),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _Welcome extends StatelessWidget {
  const _Welcome();

  @override
  Widget build(BuildContext context) {
    return Center(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(28),
        child: Column(
          children: [
            Container(
              width: 82, height: 82,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: LinearGradient(colors: [Colors.deepPurple, Colors.blue]),
              ),
              child: const Icon(Icons.auto_awesome, size: 42),
            ),
            const SizedBox(height: 20),
            const Text('AskMind AI', style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            const Text('ہر سوال، ہر پہلو سے', textAlign: TextAlign.center,
              style: TextStyle(fontSize: 18, color: Colors.white70)),
            const SizedBox(height: 24),
            const Text(
              'سوال پوچھیں اور جواب کو Positive، Negative، Risks، Alternatives اور Final Recommendation میں دیکھیں۔',
              textAlign: TextAlign.center,
              style: TextStyle(height: 1.5, color: Colors.white60),
            ),
          ],
        ),
      ),
    );
  }
}
